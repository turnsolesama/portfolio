@echo off
start "" "%~dp0ProxySwitch.exe" --install-shortcut
