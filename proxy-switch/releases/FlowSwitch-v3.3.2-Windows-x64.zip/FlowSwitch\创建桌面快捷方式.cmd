@echo off
start "" "%~dp0FlowSwitch.exe" --install-shortcut
