# 流向 FlowSwitch 3.6.0

管理已有 HTTP / SOCKS5 代理，通过固定本地入口分流，并在代理失效时按备用顺序接替。本版本增加系统托盘和内核恢复。

## 关闭窗口与停止服务

- 默认点击窗口关闭按钮会收起到 Windows 右下角系统托盘，代理入口继续运行。图标也可能位于托盘的隐藏图标区域。
- 双击图标或右键「打开主界面」恢复窗口；再次双击桌面入口也会唤醒同一配置目录的窗口。
- 右键「停止代理服务并退出」才会恢复仍归属本会话的系统代理和用户代理变量，再停止自有内核。停止失败时保留窗口和会话并说明原因。
- 右键可取消「关闭窗口后驻留托盘」，将关闭按钮恢复为停止并退出。此偏好保存在本机 ui-settings.json。
- 这是当前用户会话内的后台常驻，不是 Windows 系统服务。注销、关机或界面进程崩溃仍走安全恢复。没有自动启用开机常驻、TUN 或其他客户端设置。

## 入口自动恢复

独立模式的内核异常退出后，五分钟内最多重启三次，依次等待 1、2、4 秒；每次检查固定端口及控制接口。已验证、仍有效的当前备用出口会被保留。全部上游不可用只暂停出口，不触发无限内核重启，不默认转直连。

重试耗尽、监听被其他程序占用或 supervisor 停止时，看门狗恢复仍属于当前会话的设置。恢复写入失败最多尝试三次，保留记录并提示；不覆盖其他软件之后修改的代理，不结束用户应用。

## Google 登录报本地端口拒绝连接

先启动流向并等待固定入口就绪，再打开需要代理的应用。「诊断与工具 → Google 登录诊断」区分本地入口、代理握手、目标 HTTPS 响应。诊断仅对固定 Google OAuth 地址发送无凭据 HEAD，不读取令牌、Cookie 或账号。404、401 或 CONNECT 200 都不代表账号登录成功。

系统设置恢复无法更改已运行应用继承的环境变量或缓存。若错误仍指向旧端口，请保存工作后完整退出并重新打开该应用，必要时重开其启动器。FlowSwitch 不会代替你结束应用。

## 安装与升级

Windows 10 1809+ / Windows 11 x64。完整解压 Windows 程序包，双击 FlowSwitch.exe，保留 app。包内沿用锁定的 Node.js 24.19.0、mihomo 1.19.29 标准/兼容内核与许可证，首次运行不下载组件。

更新前正常停止旧版；保留 `%USERPROFILE%\.proxyswitch`，新包不覆盖个人设置。独立分流仍由用户显式启用；旧的 Clash 适配不会自动迁移。源代码和程序包不包含代理服务、节点、订阅或账户。

## 日志与验证

本机 gateway/lifecycle-core.jsonl 记录启动、退出码、退避、就绪失败与停止原因，单文件约 256 KiB，最多保留一个轮转副本；lifecycle-session.jsonl 最多约 256 KiB，记录设置恢复事件。只保留固定事件码和数字，不保存原始内核输出、目标网址或凭据。failover-events.json 继续保留最近 100 条接替记录。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-All.ps1
node .\Test-Lifecycle.cjs <已存在的内核EXE绝对路径>
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File .\Test-TrayLifecycle.ps1 -CorePath <内核EXE绝对路径>
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-SupervisorRecovery.ps1 -CorePath <内核EXE绝对路径>
node .\Test-IndependentIntegration.cjs <内核EXE绝对路径>
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Build-WindowsPackage.ps1 -Destination <全新目录> -RuntimeDirectory <已验证的app/runtime目录>
```

`Test-WindowsPackage.ps1 -PackageDirectory <包目录>` 验收完整程序包，`Test-RuntimeBundle.ps1` 验收随包运行组件。所有故障注入只使用隔离配置和测试进程；不能替代目标电脑的真实账号登录与长期使用验收。开发约束见 [AGENTS.md](AGENTS.md)，版本记录见 [CHANGELOG.md](CHANGELOG.md)，许可证见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
